<?php
echo 'Hello, Bingo!';
